

#ifndef DEBUG_H
#define DEBUG_H

#define DEBUGl1 false
#define DEBUGl2 false
#define DEBUGl3 false
#define DEBUGl4 false

#endif
